"use strict";

$(".toggle-link").click(function () {
  let hiddenParas = $(".hidden");

  if (hiddenParas.is(":visible")) {
    hiddenParas.slideUp();
    $(this).text("Read More");
  } else {
    hiddenParas.slideDown();
    $(this).text("Read Less");
  }
});

// Cart Js

let cart = {
  silver: { price: 10000, qty: 0 },
  gold: { price: 20000, qty: 0 },
  platinum: { price: 30000, qty: 0 }
};

let activePackage = null;

// Add first time
function addPackage(type) {
  resetAll();                // reset other packages
  activePackage = type;
  cart[type].qty = 1;

  renderControl(type);
  updateSummary();
}

// Increase qty
function increment(type) {
  if (activePackage !== type) return;

  cart[type].qty++;
  renderControl(type);
  updateSummary();
}

// Decrease qty
function decrement(type) {
  cart[type].qty--;

  if (cart[type].qty <= 0) {
    resetAll();
  } else {
    renderControl(type);
  }

  updateSummary();
}

// Reset everything
function resetAll() {
  for (let key in cart) {
    cart[key].qty = 0;
    document.getElementById(`control-${key}`).innerHTML =
      `<button class="btn btn-outline-danger" onclick="addPackage('${key}')">Add</button>`;
  }
  activePackage = null;
}

// Render + / -
function renderControl(type) {
  document.getElementById(`control-${type}`).innerHTML = `
    <div class="counter">
      <button onclick="decrement('${type}')">−</button>
      <span>${cart[type].qty}</span>
      <button onclick="increment('${type}')">+</button>
    </div>`;
}

// Footer summary
function updateSummary() {
  let qty = 0;
  let total = 0;

  if (activePackage) {
    qty = cart[activePackage].qty;
    total = cart[activePackage].qty * cart[activePackage].price;
  }

  document.getElementById("totalCount").innerText = qty;
  document.getElementById("totalPrice").innerText = total;

  document.getElementById("proceedBtn").disabled = qty === 0;
}

function goToCheckout() {
  if (!activePackage) return;

  const checkoutData = {
    packageKey: activePackage,
    packageName:
      activePackage === "silver"
        ? "Silver Package"
        : activePackage === "gold"
        ? "Gold Package"
        : "Platinum Package",
    price: cart[activePackage].price,
    qty: cart[activePackage].qty
  };

  localStorage.setItem("checkoutData", JSON.stringify(checkoutData));

  window.location.href = "checkout.html";
}

// Checkout Js

function goBackToCart() {
  window.location.href = "cart.html";
}

const data = JSON.parse(localStorage.getItem("checkoutData"));

// Safety check
if (!data) {
  window.location.href = "cart.html";
}

const bookingFee = 50;

const subTotal = data.price * data.qty;
const finalTotal = subTotal + bookingFee;

// Inject values into DOM
document.getElementById("packageName").innerText = data.packageName;
document.getElementById("packagePrice").innerText = data.price.toLocaleString();
document.getElementById("packageQty").innerText = data.qty;

document.getElementById("subTotal").innerText = subTotal.toLocaleString();
document.getElementById("finalTotal").innerText = finalTotal.toFixed(2);
