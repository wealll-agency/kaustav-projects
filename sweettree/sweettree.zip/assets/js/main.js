$(document).ready(function () {
  // Hero Slider
  $(".hero-slider").owlCarousel({
    items: 1,
    loop: true,
    autoplay: true,
    autoplayTimeout: 5000,
    nav: false,
    dots: true,
    autoHeight: true,
  });

  // Collection Slider
  $(".collection-slider").owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots: false,
    autoplay: true,
    autoplayTimeout: 4000,
    responsive: {
      0: { items: 2 },
      576: { items: 3 },
      768: { items: 4 },
      992: { items: 5 },
    },
  });

  // Brands Slider
  var brandsOwl = $(".brands-slider");

  brandsOwl.owlCarousel({
    center: true,
    loop: true,
    margin: 30, // Uniform base margin, scaling does the rest
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 3000,
    responsive: {
      0: { items: 3, margin: 10 },
      576: { items: 3, margin: 10 },
      768: { items: 5, margin: 20 },
      992: { items: 5, margin: 30 },
    },
  });

  // Testimonial Custom Slider
  var testimonialOwl = $(".testimonial-slider");
  testimonialOwl.owlCarousel({
    loop: true,
    margin: 30,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 6000,
    responsive: {
      0: { items: 1 },
      768: { items: 2 },
      992: { items: 3 },
    },
  });

  // Product Sliders (General)
  $(".product-slider").owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    navText: [
      '<i class="fas fa-angle-left"></i>',
      '<i class="fas fa-angle-right"></i>',
    ],
    dots: false,
    autoplay: true,
    autoplayTimeout: 5000,
    responsive: {
      0: { items: 1 },
      576: { items: 2 },
      768: { items: 3 },
      992: { items: 4 },
    },
  });

  // Offers Slider
  $(".offers-slider").owlCarousel({
    center: true,
    loop: true,
    margin: -120, // Negative margin for overlap effect
    nav: true,
    navText: [
      "<i class='fas fa-chevron-left'></i>",
      "<i class='fas fa-chevron-right'></i>",
    ],
    dots: false,
    autoplay: true,
    autoplayTimeout: 5000,
    responsive: {
      0: { items: 1, margin: 10 },
      768: { items: 3, margin: -60 },
      992: { items: 3, margin: -120 },
    },
  });

  // Custom Navigation Events
  $(".custom-next").click(function () {
    testimonialOwl.trigger("next.owl.carousel");
  });
  $(".custom-prev").click(function () {
    testimonialOwl.trigger("prev.owl.carousel");
  });

  // Combo Slider
  var comboOwl = $(".combo-slider");
  comboOwl.owlCarousel({
    loop: true,
    margin: 20,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 5000,
    autoWidth: true,
    responsive: {
      0: { margin: 10 },
      768: { margin: 15 },
      992: { margin: 20 },
    },
  });

  $(".prev-combo").click(function () {
    comboOwl.trigger("prev.owl.carousel");
  });
  $(".next-combo").click(function () {
    comboOwl.trigger("next.owl.carousel");
  });

  // Blog Slider
  var blogOwl = $(".blog-slider");
  blogOwl.owlCarousel({
    loop: false,
    margin: 20,
    nav: true,
    navText: [
      '<i class="fas fa-angle-left"></i>',
      '<i class="fas fa-angle-right"></i>',
    ],
    dots: false,
    responsive: {
      0: { items: 1.2 },
      768: { items: 2 },
      992: { items: 3 },
    },
  });

  // Animated Auto Counter for Store Locator Stats
  var counterObserver = new IntersectionObserver(
    function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          $(entry.target)
            .find(".counter")
            .each(function () {
              var $this = $(this);
              var targetVal = parseInt($this.data("target"), 10);

              $({ Counter: 0 }).animate(
                {
                  Counter: targetVal,
                },
                {
                  duration: 2500,
                  easing: "swing",
                  step: function () {
                    $this.text(Math.ceil(this.Counter));
                  },
                  complete: function () {
                    $this.text(targetVal); // Guarantee exact final number
                  },
                },
              );
            });
          observer.unobserve(entry.target); // Run once per page load
        }
      });
    },
    { threshold: 0.5 },
  );

  var statsContainer = document.querySelector(".stats-box");
  if (statsContainer) {
    counterObserver.observe(statsContainer);
  }

  // Whole Spices Slider
  var spiceOwl = $(".spice-slider");
  spiceOwl.owlCarousel({
    loop: false,
    margin: 20,
    nav: true,
    navText: [
      '<i class="fas fa-angle-left"></i>',
      '<i class="fas fa-angle-right"></i>',
    ],
    dots: false,
    responsive: {
      0: { items: 1.2 },
      576: { items: 2.2 },
      768: { items: 3 },
      992: { items: 3 },
      1200: { items: 3 },
    },
  });
});
